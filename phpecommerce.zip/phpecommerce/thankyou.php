


<?php include('db.php') ?>
<?php require_once('include/function.php'); ?>
<?php $title = $mywebsitename;?>
<?php include('header.php') ?>
    <div class="myform" style="   background: none repeat scroll 0 0 #CFBDF0;
    border: 5px solid #A38ECB;
    border-radius: 20px;
    color: #FFFFFF;
    float: left;
    margin: 20px 266px;
    min-height: 260px;
    padding: 20px;
    width: 40%;">
          <h3 style="color: #FFFFFF;
    font-size: 16px;
    margin: 87px 0 97px;line-height:25px">Thank you for your Valuable time for Filling the Form, We will check your details and Get back to you in Short time. Good day</h3>

    </div>
</div>
<?php include('footer.php') ?>