<?php

/* Google App Client Id */
define('CLIENT_ID', '113581286954-ktooub37rcu4d1of0vhremvc621d5fss.apps.googleusercontent.com');

/* Google App Client Secret */
define('CLIENT_SECRET', 'G8W7W0la3lPpinUuaYG_K5Eo');

/* Google App Redirect Url */
define('CLIENT_REDIRECT_URL', 'http://glorywebsdev.com/ecommerce/gauth.php');

?>