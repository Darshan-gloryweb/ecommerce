<?php  require_once('db.php'); ?>
<?php include('include/start_session.php'); ?>
<?php  $title = 'Cancel | '.$mywebsitename; ?>
<?php require_once('include/function.php'); ?>
<?php require_once('header.php');?>
<div class="cart">
<p style="font-size:20px;float:left;margin:10px;border:1px solid rgb(218,218,218);width:95%;padding:10px;color:rgb(235,61,0);border-radius:5px;">  Your Order Has Been Cancelled..</p>
</div>
</div>
<?php require_once('footer.php');?>

